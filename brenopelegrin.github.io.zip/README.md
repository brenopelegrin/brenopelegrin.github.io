# brenopelegrin.github.io
Ainda em construção. Volte daqui alguns dias e verá um site construído em Gatsby :)
 

## 🔗 Links
Enquanto isso, você pode visitar meu perfil do GitHub ou o Currículo Lattes nos links abaixo.

[![github](	https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/brenopelegrin)

<h4> <img src="https://raw.githubusercontent.com/brenopelegrin/brenopelegrin/main/lattes-icon.png"
  width="32"
  height="32"
  style="float:left;"> <a href="http://lattes.cnpq.br/3052573016505608">Lattes CV</a></h4>
